
  # NeuroFlow

  This is a code bundle for NeuroFlow. The original project is available at https://www.figma.com/design/nqRKeZ8jf7gbK9ujbBS1dM/NeuroFlow.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  