import { useState, useEffect, useRef } from 'react';
import { Activity, Timer, TrendingUp, Cpu, Zap, BarChart3, Camera, Wifi, Cloud, Network, Brain, CheckCircle, AlertTriangle, Clock, Target } from 'lucide-react';
import { StatCard } from '../components/StatCard';
import { TrafficLight } from '../components/TrafficLight';
import { TrafficFlowChart } from '../components/TrafficFlowChart';
import { PredictiveChart } from '../components/PredictiveChart';
import { motion, useInView } from 'motion/react';
import { Switch } from '../components/ui/switch';

const trafficData = [
  { time: '00:00', north: 25, south: 48, east: 62, west: 35 },
  { time: '04:00', north: 15, south: 22, east: 38, west: 28 },
  { time: '08:00', north: 85, south: 68, east: 92, west: 75 },
  { time: '12:00', north: 55, south: 72, east: 48, west: 65 },
  { time: '16:00', north: 92, south: 58, east: 78, west: 88 },
  { time: '20:00', north: 42, south: 65, east: 55, west: 48 },
];

const predictiveData = [
  { time: 'Now', congestion: 65 },
  { time: '+1m', congestion: 68 },
  { time: '+2m', congestion: 72 },
  { time: '+3m', congestion: 78 },
  { time: '+4m', congestion: 82 },
  { time: '+5m', congestion: 85 },
];

const lanes = [
  { direction: 'North', density: 75, color: 'bg-red-500', waiting: 45 },
  { direction: 'South', density: 62, color: 'bg-yellow-500', waiting: 32 },
  { direction: 'East', density: 45, color: 'bg-green-500', waiting: 18 },
  { direction: 'West', density: 58, color: 'bg-orange-500', waiting: 28 },
];

// Animated car component
function Car({ direction, delay = 0 }: { direction: 'north' | 'south' | 'east' | 'west'; delay?: number }) {
  const animationConfig = {
    north: { x: '0%', fromY: '100%', toY: '-100%' },
    south: { x: '0%', fromY: '-100%', toY: '100%' },
    east: { y: '0%', fromX: '-100%', toX: '100%' },
    west: { y: '0%', fromX: '100%', toX: '-100%' },
  };

  const config = animationConfig[direction];

  return (
    <motion.div
      className="absolute w-5 h-8 bg-gradient-to-b from-blue-400 to-blue-600 rounded shadow-lg"
      initial={{
        x: 'fromX' in config ? config.fromX : config.x,
        y: 'fromY' in config ? config.fromY : config.y,
      }}
      animate={{
        x: 'toX' in config ? config.toX : config.x,
        y: 'toY' in config ? config.toY : config.y,
      }}
      transition={{
        duration: 4,
        delay,
        repeat: Infinity,
        ease: 'linear',
      }}
    />
  );
}

// Scroll-reveal wrapper with smooth fade-in
function ScrollReveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
      transition={{ duration: 0.7, delay, ease: 'easeOut' }}
    >
      {children}
    </motion.div>
  );
}

export function Dashboard() {
  const [activeSignal, setActiveSignal] = useState<'North' | 'South' | 'East' | 'West'>('North');
  const [timer, setTimer] = useState(45);
  const [isAutoMode, setIsAutoMode] = useState(true);
  const [modelAccuracy, setModelAccuracy] = useState(94.2);
  const [isLearning, setIsLearning] = useState(false);
  const [isSpeedMode, setIsSpeedMode] = useState(false);

  // Simulate model learning
  useEffect(() => {
    const learningInterval = setInterval(() => {
      setIsLearning(true);
      setModelAccuracy(prev => {
        const change = (Math.random() - 0.5) * 0.3;
        return Math.min(99.9, Math.max(90, prev + change));
      });
      setTimeout(() => setIsLearning(false), 2000);
    }, 10000);

    return () => clearInterval(learningInterval);
  }, []);

  useEffect(() => {
    if (!isAutoMode) return;

    const interval = setInterval(() => {
      setTimer(prev => {
        if (prev <= 1) {
          const directions: Array<'North' | 'South' | 'East' | 'West'> = ['North', 'South', 'East', 'West'];
          const currentIndex = directions.indexOf(activeSignal);
          const nextIndex = (currentIndex + 1) % directions.length;
          setActiveSignal(directions[nextIndex]);
          return 45;
        }
        return prev - 1;
      });
    }, isSpeedMode ? 500 : 1000); // 2x speed when isSpeedMode is true

    return () => clearInterval(interval);
  }, [activeSignal, isAutoMode, isSpeedMode]);

  // Get current time phase
  const getCurrentPhase = () => {
    const hour = new Date().getHours();
    if (hour >= 7 && hour <= 9) return { label: 'Morning Peak', color: 'text-orange-600 dark:text-orange-400', bg: 'bg-orange-100 dark:bg-orange-900/30' };
    if (hour >= 17 && hour <= 19) return { label: 'Evening Peak', color: 'text-red-600 dark:text-red-400', bg: 'bg-red-100 dark:bg-red-900/30' };
    if (hour >= 23 || hour <= 5) return { label: 'Low Traffic', color: 'text-green-600 dark:text-green-400', bg: 'bg-green-100 dark:bg-green-900/30' };
    return { label: 'Normal Traffic', color: 'text-blue-600 dark:text-blue-400', bg: 'bg-blue-100 dark:bg-blue-900/30' };
  };

  const phase = getCurrentPhase();

  // AI Decision explanation
  const activeLane = lanes.find(l => l.direction === activeSignal);
  const confidenceScore = 87 + Math.floor(Math.random() * 10);

  return (
    <div className="space-y-6">
      {/* Header with Smart City Integration */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="flex items-center justify-between"
      >
        <div>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            NeuroFlow: Intelligent Traffic Control System
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Real-time monitoring powered by Neuro-Fuzzy AI
          </p>
        </div>

        {/* Smart City Status Badges */}
        <div className="flex items-center gap-3">
          <motion.div
            className="flex items-center gap-2 px-4 py-2 bg-green-100 dark:bg-green-900/30 rounded-lg border border-green-200 dark:border-green-800"
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Cloud className="w-4 h-4 text-green-600 dark:text-green-400" />
            <span className="text-sm font-semibold text-green-700 dark:text-green-400">Cloud Connected</span>
          </motion.div>
          <div className="flex items-center gap-2 px-4 py-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg border border-blue-200 dark:border-blue-800">
            <Wifi className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span className="text-sm font-semibold text-blue-700 dark:text-blue-400">IoT Enabled</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-purple-100 dark:bg-purple-900/30 rounded-lg border border-purple-200 dark:border-purple-800">
            <Network className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            <span className="text-sm font-semibold text-purple-700 dark:text-purple-400">Smart City Ready</span>
          </div>
        </div>
      </motion.div>

      {/* Auto/Manual Mode Toggle & Real-Time Learning */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ScrollReveal delay={0.1}>
          <motion.div
            className="bg-white dark:bg-gray-900 rounded-xl p-4 shadow-lg dark:shadow-xl dark:shadow-gray-900/50 border border-gray-200 dark:border-gray-800"
            whileHover={{ scale: 1.02, boxShadow: '0 8px 30px rgba(0,0,0,0.12)' }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${isAutoMode ? 'bg-green-100 dark:bg-green-900/30' : 'bg-gray-100 dark:bg-gray-800'}`}>
                  <Cpu className={`w-5 h-5 ${isAutoMode ? 'text-green-600 dark:text-green-400' : 'text-gray-600 dark:text-gray-400'}`} />
                </div>
                <div>
                  <p className="font-semibold text-gray-900 dark:text-white">Control Mode</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {isAutoMode ? 'AI Controlled' : 'Manual Override'}
                  </p>
                </div>
              </div>
              <Switch checked={isAutoMode} onCheckedChange={setIsAutoMode} />
            </div>
          </motion.div>
        </ScrollReveal>

        <ScrollReveal delay={0.15}>
          <motion.div
            className="bg-white dark:bg-gray-900 rounded-xl p-4 shadow-lg dark:shadow-xl dark:shadow-gray-900/50 border border-gray-200 dark:border-gray-800"
            whileHover={{ scale: 1.02, boxShadow: '0 8px 30px rgba(0,0,0,0.12)' }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <motion.div
                  className={`p-2 rounded-lg ${isLearning ? 'bg-blue-100 dark:bg-blue-900/30' : 'bg-green-100 dark:bg-green-900/30'}`}
                  animate={isLearning ? { scale: [1, 1.1, 1] } : {}}
                  transition={{ duration: 0.5, repeat: isLearning ? Infinity : 0 }}
                >
                  <Brain className={`w-5 h-5 ${isLearning ? 'text-blue-600 dark:text-blue-400' : 'text-green-600 dark:text-green-400'}`} />
                </motion.div>
                <div>
                  <p className="font-semibold text-gray-900 dark:text-white">
                    {isLearning ? 'Model Learning...' : 'Model Stable'}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Accuracy: {modelAccuracy.toFixed(1)}%
                  </p>
                </div>
              </div>
              <motion.div
                className={`px-3 py-1 rounded-full text-xs font-semibold ${isLearning ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400' : 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400'}`}
                animate={isLearning ? { opacity: [1, 0.7, 1] } : {}}
                transition={{ duration: 1, repeat: isLearning ? Infinity : 0 }}
              >
                {isLearning ? 'LEARNING' : 'READY'}
              </motion.div>
            </div>
          </motion.div>
        </ScrollReveal>
      </div>

      {/* Peak Hour Detection & Performance Insights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ScrollReveal delay={0.2}>
          <motion.div
            className={`${phase.bg} rounded-xl p-4 border ${phase.color.replace('text-', 'border-')}`}
            whileHover={{ scale: 1.02 }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <div className="flex items-center gap-3">
              <Clock className={`w-6 h-6 ${phase.color}`} />
              <div>
                <p className={`font-bold ${phase.color}`}>{phase.label}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          </motion.div>
        </ScrollReveal>

        <ScrollReveal delay={0.25}>
          <motion.div
            className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl p-4 text-white"
            whileHover={{ scale: 1.02, boxShadow: '0 8px 30px rgba(16, 185, 129, 0.4)' }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Target className="w-6 h-6" />
                <div>
                  <p className="font-bold">Efficiency Score</p>
                  <p className="text-sm text-green-100">32% congestion reduction</p>
                </div>
              </div>
              <span className="text-3xl font-bold">87%</span>
            </div>
          </motion.div>
        </ScrollReveal>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <ScrollReveal key="active-signal" delay={0.3}>
          <motion.div whileHover={{ y: -5, boxShadow: '0 8px 30px rgba(0,0,0,0.12)' }} transition={{ type: 'spring', stiffness: 300 }}>
            <StatCard title="Active Signal" value={activeSignal} icon={Activity} color="green" />
          </motion.div>
        </ScrollReveal>
        <ScrollReveal key="green-timer" delay={0.35}>
          <motion.div whileHover={{ y: -5, boxShadow: '0 8px 30px rgba(0,0,0,0.12)' }} transition={{ type: 'spring', stiffness: 300 }}>
            <StatCard 
              title="Green Timer" 
              value={`${timer}s`} 
              icon={Timer} 
              color="yellow" 
              trend="Time remaining"
              showSpeedButton={true}
              onSpeedToggle={() => setIsSpeedMode(!isSpeedMode)}
              isSpeedMode={isSpeedMode}
            />
          </motion.div>
        </ScrollReveal>
        <ScrollReveal key="avg-flow" delay={0.4}>
          <motion.div whileHover={{ y: -5, boxShadow: '0 8px 30px rgba(0,0,0,0.12)' }} transition={{ type: 'spring', stiffness: 300 }}>
            <StatCard title="Avg Flow Rate" value="24.5" icon={TrendingUp} color="blue" trend="+12% from yesterday" />
          </motion.div>
        </ScrollReveal>
        <ScrollReveal key="system-status" delay={0.45}>
          <motion.div whileHover={{ y: -5, boxShadow: '0 8px 30px rgba(0,0,0,0.12)' }} transition={{ type: 'spring', stiffness: 300 }}>
            <StatCard title="System Status" value="AI Active" icon={Cpu} color="purple" trend="Learning mode enabled" />
          </motion.div>
        </ScrollReveal>
      </div>

      {/* AI Explainability Panel */}
      <ScrollReveal delay={0.4}>
        <motion.div
          className="bg-gradient-to-r from-purple-500 to-indigo-600 rounded-xl p-6 shadow-lg text-white"
          whileHover={{ scale: 1.01, boxShadow: '0 12px 40px rgba(139, 92, 246, 0.4)' }}
          transition={{ type: 'spring', stiffness: 300 }}
        >
          <div className="flex items-start gap-4">
            <motion.div
              className="p-3 bg-white/20 rounded-lg"
              animate={{ rotate: [0, 5, -5, 0] }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <Brain className="w-8 h-8" />
            </motion.div>
            <div className="flex-1">
              <h3 className="text-xl font-bold mb-2 flex items-center gap-2">
                AI Decision Explanation
                <span className="px-3 py-1 bg-white/20 rounded-full text-sm">Confidence: {confidenceScore}%</span>
              </h3>
              <p className="text-purple-100 mb-4">
                <strong>{activeSignal}</strong> lane selected due to <strong>HIGH density ({activeLane?.density}%)</strong> and <strong>LONG waiting time ({activeLane?.waiting}s)</strong>
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                  <p className="text-sm text-purple-200">Active Rule</p>
                  <p className="font-semibold">IF density HIGH AND wait HIGH</p>
                </div>
                <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                  <p className="text-sm text-purple-200">Then Action</p>
                  <p className="font-semibold">Green time = LONG (45s)</p>
                </div>
                <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                  <p className="text-sm text-purple-200">Neural Weight</p>
                  <p className="font-semibold">Priority: 0.{confidenceScore}</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </ScrollReveal>

      {/* Main Content Grid - Intersection + IoT Cameras + Predictive */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 3D 4-Way Intersection Visualization */}
        <ScrollReveal delay={0.45}>
          <motion.div
            className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-lg dark:shadow-xl dark:shadow-gray-900/50 border border-gray-200 dark:border-gray-800"
            whileHover={{ scale: 1.01 }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
              Live Traffic Overview
            </h3>

            <div
              className="relative w-full aspect-square max-w-2xl mx-auto"
              style={{
                perspective: '1500px',
                transformStyle: 'preserve-3d'
              }}
            >
              {/* Intersection Center with Glow */}
              <motion.div
                className="absolute inset-0 flex items-center justify-center"
                animate={{
                  boxShadow: isAutoMode
                    ? `0 0 40px rgba(16, 185, 129, 0.3)`
                    : '0 0 20px rgba(0, 0, 0, 0.1)'
                }}
              >
                <div className="w-48 h-48 bg-gray-800 dark:bg-gray-700 rounded-lg shadow-2xl"></div>
              </motion.div>

              {/* North Road with Cars */}
              <motion.div
                className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-1/3 bg-gray-600 dark:bg-gray-700"
                animate={{
                  boxShadow: activeSignal === 'North'
                    ? '0 0 30px rgba(16, 185, 129, 0.6), inset 0 0 20px rgba(16, 185, 129, 0.2)'
                    : '0 0 0px rgba(0, 0, 0, 0)'
                }}
                transition={{ duration: 0.3 }}
              >
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
                  <div className="w-2 h-10 bg-white/50 rounded"></div>
                  <div className="w-2 h-10 bg-white/50 rounded"></div>
                  <div className="w-2 h-10 bg-white/50 rounded"></div>
                </div>
                <div className="absolute top-6 left-1/2 -translate-x-1/2 z-10">
                  <TrafficLight active={activeSignal === 'North' ? 'green' : 'red'} size="lg" />
                </div>
                {activeSignal === 'North' && (
                  <>
                    <Car direction="north" delay={0} />
                    <Car direction="north" delay={2} />
                  </>
                )}
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white font-bold">NORTH</div>
              </motion.div>

              {/* South Road */}
              <motion.div
                className="absolute bottom-0 left-1/2 -translate-x-1/2 w-48 h-1/3 bg-gray-600 dark:bg-gray-700"
                animate={{
                  boxShadow: activeSignal === 'South'
                    ? '0 0 30px rgba(16, 185, 129, 0.6), inset 0 0 20px rgba(16, 185, 129, 0.2)'
                    : '0 0 0px rgba(0, 0, 0, 0)'
                }}
                transition={{ duration: 0.3 }}
              >
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
                  <div className="w-2 h-10 bg-white/50 rounded"></div>
                  <div className="w-2 h-10 bg-white/50 rounded"></div>
                  <div className="w-2 h-10 bg-white/50 rounded"></div>
                </div>
                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10">
                  <TrafficLight active={activeSignal === 'South' ? 'green' : 'red'} size="lg" />
                </div>
                {activeSignal === 'South' && (
                  <>
                    <Car direction="south" delay={0} />
                    <Car direction="south" delay={2} />
                  </>
                )}
                <div className="absolute top-4 left-1/2 -translate-x-1/2 text-white font-bold">SOUTH</div>
              </motion.div>

              {/* East Road */}
              <motion.div
                className="absolute right-0 top-1/2 -translate-y-1/2 h-48 w-1/3 bg-gray-600 dark:bg-gray-700"
                animate={{
                  boxShadow: activeSignal === 'East'
                    ? '0 0 30px rgba(16, 185, 129, 0.6), inset 0 0 20px rgba(16, 185, 129, 0.2)'
                    : '0 0 0px rgba(0, 0, 0, 0)'
                }}
                transition={{ duration: 0.3 }}
              >
                <div className="absolute inset-0 flex items-center justify-center gap-4">
                  <div className="h-2 w-10 bg-white/50 rounded"></div>
                  <div className="h-2 w-10 bg-white/50 rounded"></div>
                  <div className="h-2 w-10 bg-white/50 rounded"></div>
                </div>
                <div className="absolute right-6 top-1/2 -translate-y-1/2 z-10">
                  <TrafficLight active={activeSignal === 'East' ? 'green' : 'red'} size="lg" />
                </div>
                {activeSignal === 'East' && (
                  <>
                    <Car direction="east" delay={0} />
                    <Car direction="east" delay={2} />
                  </>
                )}
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-white font-bold">EAST</div>
              </motion.div>

              {/* West Road */}
              <motion.div
                className="absolute left-0 top-1/2 -translate-y-1/2 h-48 w-1/3 bg-gray-600 dark:bg-gray-700"
                animate={{
                  boxShadow: activeSignal === 'West'
                    ? '0 0 30px rgba(16, 185, 129, 0.6), inset 0 0 20px rgba(16, 185, 129, 0.2)'
                    : '0 0 0px rgba(0, 0, 0, 0)'
                }}
                transition={{ duration: 0.3 }}
              >
                <div className="absolute inset-0 flex items-center justify-center gap-4">
                  <div className="h-2 w-10 bg-white/50 rounded"></div>
                  <div className="h-2 w-10 bg-white/50 rounded"></div>
                  <div className="h-2 w-10 bg-white/50 rounded"></div>
                </div>
                <div className="absolute left-6 top-1/2 -translate-y-1/2 z-10">
                  <TrafficLight active={activeSignal === 'West' ? 'green' : 'red'} size="lg" />
                </div>
                {activeSignal === 'West' && (
                  <>
                    <Car direction="west" delay={0} />
                    <Car direction="west" delay={2} />
                  </>
                )}
                <div className="absolute right-4 top-1/2 -translate-y-1/2 text-white font-bold">WEST</div>
              </motion.div>
            </div>
          </motion.div>
        </ScrollReveal>

        {/* IoT Camera Simulation */}
        <ScrollReveal delay={0.5}>
          <motion.div
            className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-lg dark:shadow-xl dark:shadow-gray-900/50 border border-gray-200 dark:border-gray-800"
            whileHover={{ scale: 1.01 }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">IoT Camera Feeds</h3>
              <motion.div
                className="flex items-center gap-2 px-3 py-1 bg-green-100 dark:bg-green-900/30 rounded-full"
                animate={{ opacity: [1, 0.7, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-xs font-semibold text-green-700 dark:text-green-400">LIVE</span>
              </motion.div>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-6">
              {['North', 'South', 'East', 'West'].map((direction, idx) => (
                <motion.div
                  key={direction}
                  className="relative bg-gray-800 rounded-lg overflow-hidden aspect-video group cursor-pointer"
                  whileHover={{ scale: 1.05 }}
                  transition={{ type: 'spring', stiffness: 300 }}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-gray-900 to-gray-800 flex items-center justify-center">
                    <Camera className="w-8 h-8 text-gray-600" />
                  </div>
                  <div className="absolute top-2 left-2 px-2 py-1 bg-black/60 rounded text-xs text-white font-semibold backdrop-blur-sm">
                    {direction} Cam
                  </div>
                  <motion.div
                    className="absolute bottom-2 right-2"
                    animate={{ scale: [1, 1.2, 1], opacity: [1, 0.7, 1] }}
                    transition={{ duration: 2, repeat: Infinity, delay: idx * 0.5 }}
                  >
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  </motion.div>

                  {/* Scan line effect */}
                  <motion.div
                    className="absolute inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-green-400 to-transparent opacity-50"
                    animate={{ top: ['0%', '100%'] }}
                    transition={{ duration: 3, repeat: Infinity, ease: 'linear', delay: idx * 0.7 }}
                  />
                </motion.div>
              ))}
            </div>

            {/* Sensor Status */}
            <div className="space-y-2">
              <p className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">Sensor Status</p>
              {['Density Sensor', 'Speed Sensor', 'Vehicle Counter', 'Emergency Detector'].map((sensor, idx) => (
                <div key={sensor} className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <div className="flex items-center gap-2">
                    <motion.div
                      className="w-2 h-2 bg-green-500 rounded-full"
                      animate={{ scale: [1, 1.3, 1] }}
                      transition={{ duration: 2, repeat: Infinity, delay: idx * 0.3 }}
                    />
                    <span className="text-sm text-gray-700 dark:text-gray-300">{sensor}</span>
                  </div>
                  <span className="text-xs font-semibold text-green-600 dark:text-green-400">ONLINE</span>
                </div>
              ))}
            </div>
          </motion.div>
        </ScrollReveal>

        {/* Predictive Traffic Panel */}
        <ScrollReveal delay={0.55}>
          <motion.div
            className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-lg dark:shadow-xl dark:shadow-gray-900/50 border border-gray-200 dark:border-gray-800"
            whileHover={{ scale: 1.01 }}
            transition={{ type: 'spring', stiffness: 300 }}
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">AI Prediction</h3>
              <div className="px-3 py-1 bg-blue-100 dark:bg-blue-900/30 rounded-full">
                <span className="text-xs font-semibold text-blue-700 dark:text-blue-400">Next 5 min</span>
              </div>
            </div>

            <PredictiveChart data={predictiveData} />

            <div className="mt-6 space-y-3">
              <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800">
                <div className="flex items-center gap-2 mb-1">
                  <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                  <span className="text-sm font-semibold text-amber-700 dark:text-amber-400">Forecast Alert</span>
                </div>
                <p className="text-xs text-amber-600 dark:text-amber-500">
                  Congestion expected to increase by 20% in next 5 minutes
                </p>
              </div>

              <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Predicted Peak</span>
                  <span className="text-sm font-bold text-gray-900 dark:text-white">85%</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <motion.div
                    className="bg-gradient-to-r from-blue-500 to-cyan-500 h-2 rounded-full"
                    initial={{ width: '0%' }}
                    animate={{ width: '85%' }}
                    transition={{ duration: 1.5, ease: 'easeOut' }}
                  />
                </div>
              </div>
            </div>
          </motion.div>
        </ScrollReveal>
      </div>

      {/* Traffic Flow Chart */}
      <ScrollReveal delay={0.6}>
        <motion.div
          className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-lg dark:shadow-xl dark:shadow-gray-900/50 border border-gray-200 dark:border-gray-800"
          whileHover={{ scale: 1.005 }}
          transition={{ type: 'spring', stiffness: 300 }}
        >
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">Real-time Traffic Flow</h3>

          <TrafficFlowChart data={trafficData} />
        </motion.div>
      </ScrollReveal>
    </div>
  );
}